<body>


    <?php
    include("../elements/nav.php");
    include("../php/beveiliging.php");

    ?>


    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registration</title>
    </head>


    <div>
        <h3>Registration</h1>
            <form action="../php/Registration_submit.php" method="post">

                <?php
                $csrf = GenerateCSRF();
                ?>

                <fieldset>
                    <legend>Personalia</legend>



                    <label for="name">Username</label><br>
                    <input type="text" name="name" id="name" required placeholder="John Doe" pattern="[A-Za-z0-9]+">

                    <br>
                    <br>

                    <label for="email">Email</label> <br>
                    <input type="email" name="email" id="email" placeholder="Johndoe@gmail.com" required pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$">

                    <br>
                    <br>

                    <label for="passw">Password</label><br>
                    <input type="password" name="passw" id="passw" required placeholder="12345">

                    <br>
                    <br>


                    <label for="passw1">Confirm password</label>

                    <br>

                    <input type="password" name="passw1" id="passw1" required placeholder="*****">

                    <br>
                    <br>
                    <input type="hidden" hidden name="csrf_token" value="<?php echo $csrf; ?>">
                    <button type="submit" id="btn"> Submit</button>
                    <br>
                </fieldset>
            </form>

            <p>Do you have an account? Login <a href="Login.php">here</a></p>
    </div>
    <?php

    include("../elements/footer.php");
    ?>
</body>
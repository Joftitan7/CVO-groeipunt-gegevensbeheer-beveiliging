<body>



    <?php
    include("../elements/nav.php");
    include("../php/beveiliging.php");

    ?>

    <link rel="stylesheet" href="../css/contact_form.css">
    <form action="../php/contact_form_submit.php" method="post">

        <?php
        $crsf = GenerateCSRF();
        ?>

        <fieldset>
            <legend>

                <h2>
                    <p>Contact & Service form</p>
                </h2>
            </legend>

            <label for="product_id">Please enter the product number here</label> <br>
            <input type="number" name="product_id" id="product_id" placeholder="1234567890" pattern="^[0-9]{1,10}$">

            <br>
            <br>
            <br>

            <label for="msg">Please write your complaint or feedback</label><br>
            <textarea name="message" id="msg" placeholder="Please remember to be respectful and considerate."></textarea>

            <br>
            <br>
            <br>

            <label for="file">
                <p>Select a file or image (optional) </p>
            </label>

            <input type="file" name="file" id="file">

            <br>
            <br>

            <label for="email">
                <p>What Email can we contact you on?</p>
            </label>
            <input type="email" name="email" id="email" placeholder="Johndoe@gmail.com" pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$">

            <br>
            <br>

            <label for="phone">What Number can we contact you on?</label> <br>
            <input type="tel" name="phone" id="phone" placeholder="+32 xxxxxxxx" pattern="^\+?[0-9]{8,15}$">

            <br>
            <br>
            <input type="hidden" hidden name="csrf_token" value="<?php echo $crsf; ?>">
            <button type="submit" id="btn"> Submit</button>

            <br>
        </fieldset>
    </form>

    <?php

    include("../elements/footer.php");

    ?>

</body>